﻿-------------------------------------------------------------------------------
[EN]

MapExtractor is a tool for extracting compressed data from map files .mis and 
.lnd. It is also capable of extracting .wd and .eco files, but it's not very 
useful.

To use it simply drag and drop the file onto MapExtractor.exe.



MapPackager is a tool for packaging decompressed data back into a single file.

To use it simply drag and drop the directory containing a list of indexed files 
onto MapPackager.exe.



!!! Important !!!
Do not modify names of generated files. The tool expects to find an _ext at the 
end of the directory's name and a list of files indexed from 0.





-------------------------------------------------------------------------------
[PL]

MapExtractor to narzędzie do wypakowywania skompresowanych danych z plików map 
.mis i .lnd. Jest ono również w stanie wypakować pliki .wd i .eco, jednak nie
jest to w żaden sposób użyteczne.

Aby go użyć przeciągnij i upuść plik na MapExtractor.exe.



MapPackager to narzędzie do pakowania zdekompresowanych danych z powrotem do
jednego pliku.

Aby go użyć przeciągnij i upuść folder zawierający listę indeksowanych plików
na MapPackager.exe.



!!! Ważne !!!
Nie modyfikuj nazw generowanych plików. Narzędzie oczekuje _ext na końcu nazwy 
folderu oraz listy plików indeksowanych od 0.