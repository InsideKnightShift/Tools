﻿-------------------------------------------------------------------------------
[EN]

TexConverter is a tool for converting .tex files to .png images and vice versa. 
The tool expects to find a config.txt file within the same directory. This file 
contains a list of instructions. All of the available instructions are provided 
in a form of an example, which is shipped with the tool. You can keep these 
files for future reference.

Limits:
    - animated textures are not supported
    - paths cannot contain whitespace characters
    - texture containers :ctex cannot use :ptex_auto

!!! Important !!!
DO NOT MIX EXTRACTING AND INSERTING, this can lead to file overwrites and thus 
loss of data. Always use 2 separate TexConverter.exe, one for extracting and 
one for inserting.





-------------------------------------------------------------------------------
[PL]

TexConverter to narzędzie do konwertowania plików .tex do obrazów .png i vice
versa. Narzędzie wymaga pliku config.txt, który musi znajdować się w tym samym
folderze. Ten plik zawiera listę instrukcji. Wszystkie instrukcje są zawarte
w przykładzie dołączonym do narzędzia. Możesz go zachować na przyszłość.

Limity:
    - animowane tekstury nie są obsługiwane
    - ścieżki nie mogą zawierać spacji
    - nie można używać :ptex_auto w kontenerach tekstur :ctex

!!! Ważne !!!
NIE ŁĄCZ WYPAKOWYWANIA Z PAKOWANIEM, to może prowadzić do nadpisywania plików
i tym samym utraty danych. Zawsze trzymaj 2 osobne TexConverter.exe, jeden do
wypakowywania, drugi do pakowania.
